package com.betting;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyBetApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyBetApplication.class, args);
	}


}

